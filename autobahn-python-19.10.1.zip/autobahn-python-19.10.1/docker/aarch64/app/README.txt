Put your microservice code and assets in here.

The container will automatically start the Python script

    python client.py --realm $CBREALM --url $CBURL
