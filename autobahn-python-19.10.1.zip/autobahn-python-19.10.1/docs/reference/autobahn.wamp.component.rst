Module ``autobahn.wamp.component``
==================================

Component
---------

This is common code for both Twisted and asyncio components; see either :class:`autobahn.twisted.component.Component` or :class:`autobahn.asyncio.component.Component` for the concrete implementations.

.. autoclass:: autobahn.wamp.component.Component
    :members:
