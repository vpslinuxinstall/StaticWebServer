# WebSocket programming with Autobahn on asyncio

This folder contains complete working code examples that demonstrate [WebSocket](http://crossbario.com/blog/post/websocket-why-what-can-i-use-it/) programming with **Autobahn**|Python on [asyncio](http://docs.python.org/3.4/library/asyncio.html):

 1. [Echo](echo)
 2. [Slow Square](slowsquare)
 3. [Testee](testee)
