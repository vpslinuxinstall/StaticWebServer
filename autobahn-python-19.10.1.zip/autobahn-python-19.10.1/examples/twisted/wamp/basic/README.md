In a first terminal:

```console
crossbar start
```

In a second terminal:

```console
python client_using_apprunner.py
```

or

```console
python client_using_clientservice.py
```
