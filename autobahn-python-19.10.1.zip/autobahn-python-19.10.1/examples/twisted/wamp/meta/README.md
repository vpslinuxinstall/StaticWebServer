Shows the WAMP "meta API", which is information about subscriptions
and registrations delivered via 'wamp.'-prefixed events.

