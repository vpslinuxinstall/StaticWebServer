This shows how to use dynamic authorizers

Try changing the "if True" in "authorize.py" -- then the registration
should fail.