# this is a module so we can include it via PYTHONPATH in the example
# router's config.
