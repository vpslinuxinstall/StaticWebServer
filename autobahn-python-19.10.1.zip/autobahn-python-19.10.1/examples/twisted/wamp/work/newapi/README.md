
A single session joins a first realm, leaves and joins another realm
all over the same, still running transport.

A single session can freeze and resume over different transports.

Multiple WAMP sessions can run over a single, multiplexed WAMP transport.


Run 1 main across 1 transport.
Run N mains across 1 (multiplexed) transport.
Run N mains across N transports.
