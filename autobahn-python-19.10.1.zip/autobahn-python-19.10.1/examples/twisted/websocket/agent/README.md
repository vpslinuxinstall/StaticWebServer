
Some proof-of-concept usage of the proof-of-concept "Agent"-related
work for websocket (goal: tests!)


